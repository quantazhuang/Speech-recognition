package name.swyan.speechcalculator.data;

public interface Model {
}
