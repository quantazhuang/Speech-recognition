package name.swyan.speechcalculator.util;

public enum MessageType {
	ERROR, WARNING, SUCCESS, INFO;
};